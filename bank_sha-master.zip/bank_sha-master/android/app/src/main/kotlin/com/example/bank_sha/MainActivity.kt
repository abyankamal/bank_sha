package com.example.bank_sha

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
