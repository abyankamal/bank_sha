class ApiPath {
  static const String baseUrl = 'https://bwabank.tech/api';
}
